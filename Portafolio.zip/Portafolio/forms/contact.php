<?php
// Cambia este correo por el tuyo real
$receiving_email_address = 'guarandavalerianoarlin@gmail.com';

// Validar datos recibidos (mínimo)
if (!isset($_POST['name'], $_POST['email'], $_POST['subject'], $_POST['message'])) {
    http_response_code(400);
    echo "Faltan datos requeridos.";
    exit;
}

$name = strip_tags(trim($_POST['name']));
$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
$subject = strip_tags(trim($_POST['subject']));
$message = strip_tags(trim($_POST['message']));

if (!$email) {
    http_response_code(400);
    echo "Correo electrónico inválido.";
    exit;
}

$email_body = "Nombre: $name\n";
$email_body .= "Correo: $email\n";
$email_body .= "Asunto: $subject\n";
$email_body .= "Mensaje:\n$message\n";

$headers = "From: $name <$email>\r\n";
$headers .= "Reply-To: $email\r\n";

// Enviar correo
if (mail($receiving_email_address, $subject, $email_body, $headers)) {
    // Respuesta que espera el JS para mostrar "enviado"
    echo "OK";
} else {
    http_response_code(500);
    echo "Error al enviar el correo.";
}
?>
